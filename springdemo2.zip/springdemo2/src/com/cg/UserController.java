package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="user")
public class UserController {
	@RequestMapping(value="showlogin")
public String prepareLogin(Model model){
		model.addAttribute("login",new Login());
	return "login";
	
}
	public ModelAndView checkLogin(@ModelAttribute()){
		String username;
		String password;
		if(username.equals("avi")){
			return "login successful";
		}
	}
	public ModelAndView checkLogin(@ModelAttribute("login")Login login){
		return new ModelAndView("loginsuccess","username",login.getUsername());
	}
	@RequestMapping(value="showregister")
	public String prepareRegister(Model model){
		model.addAttribute("user",new User());
		return "register";
	}
	public String checkRegister(User user,Model model){
		model.addAttribute("user",user);
		return "registersuccess";
	}
}
